/**
 */
package fr.obeo.dsl.tuto.mindstorms;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Instruction</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.obeo.dsl.tuto.mindstorms.MindstormsPackage#getInstruction()
 * @model abstract="true"
 * @generated
 */
public interface Instruction extends EObject {
} // Instruction
