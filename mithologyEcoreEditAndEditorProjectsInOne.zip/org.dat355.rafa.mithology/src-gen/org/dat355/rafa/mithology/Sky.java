/**
 */
package org.dat355.rafa.mithology;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sky</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getSky()
 * @model
 * @generated
 */
public interface Sky extends OlympusCreature {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	int attack();

} // Sky
