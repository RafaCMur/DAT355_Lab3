/**
 */
package org.dat355.rafa.mithology;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Olympus Creature</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.OlympusCreature#getHp <em>Hp</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.OlympusCreature#getName <em>Name</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.OlympusCreature#getPower <em>Power</em>}</li>
 * </ul>
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getOlympusCreature()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface OlympusCreature extends EObject {
	/**
	 * Returns the value of the '<em><b>Hp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hp</em>' attribute.
	 * @see #setHp(Integer)
	 * @see org.dat355.rafa.mithology.MithologyPackage#getOlympusCreature_Hp()
	 * @model
	 * @generated
	 */
	Integer getHp();

	/**
	 * Sets the value of the '{@link org.dat355.rafa.mithology.OlympusCreature#getHp <em>Hp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hp</em>' attribute.
	 * @see #getHp()
	 * @generated
	 */
	void setHp(Integer value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.dat355.rafa.mithology.MithologyPackage#getOlympusCreature_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.dat355.rafa.mithology.OlympusCreature#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Power</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Power</em>' attribute.
	 * @see #setPower(int)
	 * @see org.dat355.rafa.mithology.MithologyPackage#getOlympusCreature_Power()
	 * @model
	 * @generated
	 */
	int getPower();

	/**
	 * Sets the value of the '{@link org.dat355.rafa.mithology.OlympusCreature#getPower <em>Power</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Power</em>' attribute.
	 * @see #getPower()
	 * @generated
	 */
	void setPower(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	int attack();

} // OlympusCreature
