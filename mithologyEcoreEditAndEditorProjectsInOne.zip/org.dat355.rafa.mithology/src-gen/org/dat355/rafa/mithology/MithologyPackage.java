/**
 */
package org.dat355.rafa.mithology;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.dat355.rafa.mithology.MithologyFactory
 * @model kind="package"
 * @generated
 */
public interface MithologyPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "mithology";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/mithology";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "mithology";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MithologyPackage eINSTANCE = org.dat355.rafa.mithology.impl.MithologyPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.dat355.rafa.mithology.OlympusGod <em>Olympus God</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.dat355.rafa.mithology.OlympusGod
	 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getOlympusGod()
	 * @generated
	 */
	int OLYMPUS_GOD = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_GOD__NAME = 0;

	/**
	 * The feature id for the '<em><b>Power</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_GOD__POWER = 1;

	/**
	 * The number of structural features of the '<em>Olympus God</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_GOD_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Olympus God</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_GOD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.dat355.rafa.mithology.impl.TopGodImpl <em>Top God</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.dat355.rafa.mithology.impl.TopGodImpl
	 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getTopGod()
	 * @generated
	 */
	int TOP_GOD = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_GOD__NAME = OLYMPUS_GOD__NAME;

	/**
	 * The feature id for the '<em><b>Power</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_GOD__POWER = OLYMPUS_GOD__POWER;

	/**
	 * The feature id for the '<em><b>Subordinates</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_GOD__SUBORDINATES = OLYMPUS_GOD_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Special Weapon</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_GOD__SPECIAL_WEAPON = OLYMPUS_GOD_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Creates</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_GOD__CREATES = OLYMPUS_GOD_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_GOD__CHILDREN = OLYMPUS_GOD_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Top God</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_GOD_FEATURE_COUNT = OLYMPUS_GOD_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Top God</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_GOD_OPERATION_COUNT = OLYMPUS_GOD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.dat355.rafa.mithology.OlympusCreature <em>Olympus Creature</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.dat355.rafa.mithology.OlympusCreature
	 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getOlympusCreature()
	 * @generated
	 */
	int OLYMPUS_CREATURE = 2;

	/**
	 * The feature id for the '<em><b>Hp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_CREATURE__HP = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_CREATURE__NAME = 1;

	/**
	 * The feature id for the '<em><b>Power</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_CREATURE__POWER = 2;

	/**
	 * The number of structural features of the '<em>Olympus Creature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_CREATURE_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Attack</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_CREATURE___ATTACK = 0;

	/**
	 * The number of operations of the '<em>Olympus Creature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_CREATURE_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.dat355.rafa.mithology.impl.SkyImpl <em>Sky</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.dat355.rafa.mithology.impl.SkyImpl
	 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getSky()
	 * @generated
	 */
	int SKY = 3;

	/**
	 * The feature id for the '<em><b>Hp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SKY__HP = OLYMPUS_CREATURE__HP;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SKY__NAME = OLYMPUS_CREATURE__NAME;

	/**
	 * The feature id for the '<em><b>Power</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SKY__POWER = OLYMPUS_CREATURE__POWER;

	/**
	 * The number of structural features of the '<em>Sky</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SKY_FEATURE_COUNT = OLYMPUS_CREATURE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Attack</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SKY___ATTACK = OLYMPUS_CREATURE_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Sky</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SKY_OPERATION_COUNT = OLYMPUS_CREATURE_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.dat355.rafa.mithology.impl.HellImpl <em>Hell</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.dat355.rafa.mithology.impl.HellImpl
	 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getHell()
	 * @generated
	 */
	int HELL = 4;

	/**
	 * The feature id for the '<em><b>Hp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HELL__HP = OLYMPUS_CREATURE__HP;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HELL__NAME = OLYMPUS_CREATURE__NAME;

	/**
	 * The feature id for the '<em><b>Power</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HELL__POWER = OLYMPUS_CREATURE__POWER;

	/**
	 * The number of structural features of the '<em>Hell</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HELL_FEATURE_COUNT = OLYMPUS_CREATURE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Attack</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HELL___ATTACK = OLYMPUS_CREATURE_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Hell</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HELL_OPERATION_COUNT = OLYMPUS_CREATURE_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.dat355.rafa.mithology.impl.NormalGodImpl <em>Normal God</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.dat355.rafa.mithology.impl.NormalGodImpl
	 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getNormalGod()
	 * @generated
	 */
	int NORMAL_GOD = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NORMAL_GOD__NAME = OLYMPUS_GOD__NAME;

	/**
	 * The feature id for the '<em><b>Power</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NORMAL_GOD__POWER = OLYMPUS_GOD__POWER;

	/**
	 * The feature id for the '<em><b>Children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NORMAL_GOD__CHILDREN = OLYMPUS_GOD_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Normal God</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NORMAL_GOD_FEATURE_COUNT = OLYMPUS_GOD_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Normal God</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NORMAL_GOD_OPERATION_COUNT = OLYMPUS_GOD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.dat355.rafa.mithology.impl.SemiGodImpl <em>Semi God</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.dat355.rafa.mithology.impl.SemiGodImpl
	 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getSemiGod()
	 * @generated
	 */
	int SEMI_GOD = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMI_GOD__NAME = OLYMPUS_GOD__NAME;

	/**
	 * The feature id for the '<em><b>Power</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMI_GOD__POWER = OLYMPUS_GOD__POWER;

	/**
	 * The feature id for the '<em><b>Weakness</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMI_GOD__WEAKNESS = OLYMPUS_GOD_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Semi God</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMI_GOD_FEATURE_COUNT = OLYMPUS_GOD_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Semi God</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMI_GOD_OPERATION_COUNT = OLYMPUS_GOD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.dat355.rafa.mithology.impl.OlympusImpl <em>Olympus</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.dat355.rafa.mithology.impl.OlympusImpl
	 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getOlympus()
	 * @generated
	 */
	int OLYMPUS = 7;

	/**
	 * The feature id for the '<em><b>There Are</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS__THERE_ARE = 0;

	/**
	 * The number of structural features of the '<em>Olympus</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Olympus</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLYMPUS_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link org.dat355.rafa.mithology.OlympusGod <em>Olympus God</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Olympus God</em>'.
	 * @see org.dat355.rafa.mithology.OlympusGod
	 * @generated
	 */
	EClass getOlympusGod();

	/**
	 * Returns the meta object for the attribute '{@link org.dat355.rafa.mithology.OlympusGod#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.dat355.rafa.mithology.OlympusGod#getName()
	 * @see #getOlympusGod()
	 * @generated
	 */
	EAttribute getOlympusGod_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.dat355.rafa.mithology.OlympusGod#getPower <em>Power</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Power</em>'.
	 * @see org.dat355.rafa.mithology.OlympusGod#getPower()
	 * @see #getOlympusGod()
	 * @generated
	 */
	EAttribute getOlympusGod_Power();

	/**
	 * Returns the meta object for class '{@link org.dat355.rafa.mithology.TopGod <em>Top God</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Top God</em>'.
	 * @see org.dat355.rafa.mithology.TopGod
	 * @generated
	 */
	EClass getTopGod();

	/**
	 * Returns the meta object for the containment reference list '{@link org.dat355.rafa.mithology.TopGod#getSubordinates <em>Subordinates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Subordinates</em>'.
	 * @see org.dat355.rafa.mithology.TopGod#getSubordinates()
	 * @see #getTopGod()
	 * @generated
	 */
	EReference getTopGod_Subordinates();

	/**
	 * Returns the meta object for the attribute '{@link org.dat355.rafa.mithology.TopGod#getSpecialWeapon <em>Special Weapon</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Special Weapon</em>'.
	 * @see org.dat355.rafa.mithology.TopGod#getSpecialWeapon()
	 * @see #getTopGod()
	 * @generated
	 */
	EAttribute getTopGod_SpecialWeapon();

	/**
	 * Returns the meta object for the containment reference list '{@link org.dat355.rafa.mithology.TopGod#getCreates <em>Creates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Creates</em>'.
	 * @see org.dat355.rafa.mithology.TopGod#getCreates()
	 * @see #getTopGod()
	 * @generated
	 */
	EReference getTopGod_Creates();

	/**
	 * Returns the meta object for the containment reference list '{@link org.dat355.rafa.mithology.TopGod#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Children</em>'.
	 * @see org.dat355.rafa.mithology.TopGod#getChildren()
	 * @see #getTopGod()
	 * @generated
	 */
	EReference getTopGod_Children();

	/**
	 * Returns the meta object for class '{@link org.dat355.rafa.mithology.OlympusCreature <em>Olympus Creature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Olympus Creature</em>'.
	 * @see org.dat355.rafa.mithology.OlympusCreature
	 * @generated
	 */
	EClass getOlympusCreature();

	/**
	 * Returns the meta object for the attribute '{@link org.dat355.rafa.mithology.OlympusCreature#getHp <em>Hp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Hp</em>'.
	 * @see org.dat355.rafa.mithology.OlympusCreature#getHp()
	 * @see #getOlympusCreature()
	 * @generated
	 */
	EAttribute getOlympusCreature_Hp();

	/**
	 * Returns the meta object for the attribute '{@link org.dat355.rafa.mithology.OlympusCreature#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.dat355.rafa.mithology.OlympusCreature#getName()
	 * @see #getOlympusCreature()
	 * @generated
	 */
	EAttribute getOlympusCreature_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.dat355.rafa.mithology.OlympusCreature#getPower <em>Power</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Power</em>'.
	 * @see org.dat355.rafa.mithology.OlympusCreature#getPower()
	 * @see #getOlympusCreature()
	 * @generated
	 */
	EAttribute getOlympusCreature_Power();

	/**
	 * Returns the meta object for the '{@link org.dat355.rafa.mithology.OlympusCreature#attack() <em>Attack</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Attack</em>' operation.
	 * @see org.dat355.rafa.mithology.OlympusCreature#attack()
	 * @generated
	 */
	EOperation getOlympusCreature__Attack();

	/**
	 * Returns the meta object for class '{@link org.dat355.rafa.mithology.Sky <em>Sky</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sky</em>'.
	 * @see org.dat355.rafa.mithology.Sky
	 * @generated
	 */
	EClass getSky();

	/**
	 * Returns the meta object for the '{@link org.dat355.rafa.mithology.Sky#attack() <em>Attack</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Attack</em>' operation.
	 * @see org.dat355.rafa.mithology.Sky#attack()
	 * @generated
	 */
	EOperation getSky__Attack();

	/**
	 * Returns the meta object for class '{@link org.dat355.rafa.mithology.Hell <em>Hell</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Hell</em>'.
	 * @see org.dat355.rafa.mithology.Hell
	 * @generated
	 */
	EClass getHell();

	/**
	 * Returns the meta object for the '{@link org.dat355.rafa.mithology.Hell#attack() <em>Attack</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Attack</em>' operation.
	 * @see org.dat355.rafa.mithology.Hell#attack()
	 * @generated
	 */
	EOperation getHell__Attack();

	/**
	 * Returns the meta object for class '{@link org.dat355.rafa.mithology.NormalGod <em>Normal God</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Normal God</em>'.
	 * @see org.dat355.rafa.mithology.NormalGod
	 * @generated
	 */
	EClass getNormalGod();

	/**
	 * Returns the meta object for the containment reference list '{@link org.dat355.rafa.mithology.NormalGod#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Children</em>'.
	 * @see org.dat355.rafa.mithology.NormalGod#getChildren()
	 * @see #getNormalGod()
	 * @generated
	 */
	EReference getNormalGod_Children();

	/**
	 * Returns the meta object for class '{@link org.dat355.rafa.mithology.SemiGod <em>Semi God</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Semi God</em>'.
	 * @see org.dat355.rafa.mithology.SemiGod
	 * @generated
	 */
	EClass getSemiGod();

	/**
	 * Returns the meta object for the attribute '{@link org.dat355.rafa.mithology.SemiGod#getWeakness <em>Weakness</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Weakness</em>'.
	 * @see org.dat355.rafa.mithology.SemiGod#getWeakness()
	 * @see #getSemiGod()
	 * @generated
	 */
	EAttribute getSemiGod_Weakness();

	/**
	 * Returns the meta object for class '{@link org.dat355.rafa.mithology.Olympus <em>Olympus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Olympus</em>'.
	 * @see org.dat355.rafa.mithology.Olympus
	 * @generated
	 */
	EClass getOlympus();

	/**
	 * Returns the meta object for the containment reference list '{@link org.dat355.rafa.mithology.Olympus#getThereAre <em>There Are</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>There Are</em>'.
	 * @see org.dat355.rafa.mithology.Olympus#getThereAre()
	 * @see #getOlympus()
	 * @generated
	 */
	EReference getOlympus_ThereAre();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	MithologyFactory getMithologyFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.dat355.rafa.mithology.OlympusGod <em>Olympus God</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.dat355.rafa.mithology.OlympusGod
		 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getOlympusGod()
		 * @generated
		 */
		EClass OLYMPUS_GOD = eINSTANCE.getOlympusGod();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OLYMPUS_GOD__NAME = eINSTANCE.getOlympusGod_Name();

		/**
		 * The meta object literal for the '<em><b>Power</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OLYMPUS_GOD__POWER = eINSTANCE.getOlympusGod_Power();

		/**
		 * The meta object literal for the '{@link org.dat355.rafa.mithology.impl.TopGodImpl <em>Top God</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.dat355.rafa.mithology.impl.TopGodImpl
		 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getTopGod()
		 * @generated
		 */
		EClass TOP_GOD = eINSTANCE.getTopGod();

		/**
		 * The meta object literal for the '<em><b>Subordinates</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOP_GOD__SUBORDINATES = eINSTANCE.getTopGod_Subordinates();

		/**
		 * The meta object literal for the '<em><b>Special Weapon</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TOP_GOD__SPECIAL_WEAPON = eINSTANCE.getTopGod_SpecialWeapon();

		/**
		 * The meta object literal for the '<em><b>Creates</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOP_GOD__CREATES = eINSTANCE.getTopGod_Creates();

		/**
		 * The meta object literal for the '<em><b>Children</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOP_GOD__CHILDREN = eINSTANCE.getTopGod_Children();

		/**
		 * The meta object literal for the '{@link org.dat355.rafa.mithology.OlympusCreature <em>Olympus Creature</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.dat355.rafa.mithology.OlympusCreature
		 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getOlympusCreature()
		 * @generated
		 */
		EClass OLYMPUS_CREATURE = eINSTANCE.getOlympusCreature();

		/**
		 * The meta object literal for the '<em><b>Hp</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OLYMPUS_CREATURE__HP = eINSTANCE.getOlympusCreature_Hp();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OLYMPUS_CREATURE__NAME = eINSTANCE.getOlympusCreature_Name();

		/**
		 * The meta object literal for the '<em><b>Power</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OLYMPUS_CREATURE__POWER = eINSTANCE.getOlympusCreature_Power();

		/**
		 * The meta object literal for the '<em><b>Attack</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation OLYMPUS_CREATURE___ATTACK = eINSTANCE.getOlympusCreature__Attack();

		/**
		 * The meta object literal for the '{@link org.dat355.rafa.mithology.impl.SkyImpl <em>Sky</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.dat355.rafa.mithology.impl.SkyImpl
		 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getSky()
		 * @generated
		 */
		EClass SKY = eINSTANCE.getSky();

		/**
		 * The meta object literal for the '<em><b>Attack</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SKY___ATTACK = eINSTANCE.getSky__Attack();

		/**
		 * The meta object literal for the '{@link org.dat355.rafa.mithology.impl.HellImpl <em>Hell</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.dat355.rafa.mithology.impl.HellImpl
		 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getHell()
		 * @generated
		 */
		EClass HELL = eINSTANCE.getHell();

		/**
		 * The meta object literal for the '<em><b>Attack</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation HELL___ATTACK = eINSTANCE.getHell__Attack();

		/**
		 * The meta object literal for the '{@link org.dat355.rafa.mithology.impl.NormalGodImpl <em>Normal God</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.dat355.rafa.mithology.impl.NormalGodImpl
		 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getNormalGod()
		 * @generated
		 */
		EClass NORMAL_GOD = eINSTANCE.getNormalGod();

		/**
		 * The meta object literal for the '<em><b>Children</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NORMAL_GOD__CHILDREN = eINSTANCE.getNormalGod_Children();

		/**
		 * The meta object literal for the '{@link org.dat355.rafa.mithology.impl.SemiGodImpl <em>Semi God</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.dat355.rafa.mithology.impl.SemiGodImpl
		 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getSemiGod()
		 * @generated
		 */
		EClass SEMI_GOD = eINSTANCE.getSemiGod();

		/**
		 * The meta object literal for the '<em><b>Weakness</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEMI_GOD__WEAKNESS = eINSTANCE.getSemiGod_Weakness();

		/**
		 * The meta object literal for the '{@link org.dat355.rafa.mithology.impl.OlympusImpl <em>Olympus</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.dat355.rafa.mithology.impl.OlympusImpl
		 * @see org.dat355.rafa.mithology.impl.MithologyPackageImpl#getOlympus()
		 * @generated
		 */
		EClass OLYMPUS = eINSTANCE.getOlympus();

		/**
		 * The meta object literal for the '<em><b>There Are</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OLYMPUS__THERE_ARE = eINSTANCE.getOlympus_ThereAre();

	}

} //MithologyPackage
