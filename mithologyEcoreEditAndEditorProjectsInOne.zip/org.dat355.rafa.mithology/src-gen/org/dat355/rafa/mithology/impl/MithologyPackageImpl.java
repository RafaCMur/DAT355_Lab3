/**
 */
package org.dat355.rafa.mithology.impl;

import org.dat355.rafa.mithology.Hell;
import org.dat355.rafa.mithology.MithologyFactory;
import org.dat355.rafa.mithology.MithologyPackage;
import org.dat355.rafa.mithology.NormalGod;
import org.dat355.rafa.mithology.Olympus;
import org.dat355.rafa.mithology.OlympusCreature;
import org.dat355.rafa.mithology.OlympusGod;
import org.dat355.rafa.mithology.SemiGod;
import org.dat355.rafa.mithology.Sky;
import org.dat355.rafa.mithology.TopGod;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MithologyPackageImpl extends EPackageImpl implements MithologyPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass olympusGodEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass topGodEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass olympusCreatureEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass skyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hellEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass normalGodEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass semiGodEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass olympusEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.dat355.rafa.mithology.MithologyPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private MithologyPackageImpl() {
		super(eNS_URI, MithologyFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link MithologyPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static MithologyPackage init() {
		if (isInited)
			return (MithologyPackage) EPackage.Registry.INSTANCE.getEPackage(MithologyPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredMithologyPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		MithologyPackageImpl theMithologyPackage = registeredMithologyPackage instanceof MithologyPackageImpl
				? (MithologyPackageImpl) registeredMithologyPackage
				: new MithologyPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theMithologyPackage.createPackageContents();

		// Initialize created meta-data
		theMithologyPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theMithologyPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(MithologyPackage.eNS_URI, theMithologyPackage);
		return theMithologyPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOlympusGod() {
		return olympusGodEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOlympusGod_Name() {
		return (EAttribute) olympusGodEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOlympusGod_Power() {
		return (EAttribute) olympusGodEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTopGod() {
		return topGodEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTopGod_Subordinates() {
		return (EReference) topGodEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTopGod_SpecialWeapon() {
		return (EAttribute) topGodEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTopGod_Creates() {
		return (EReference) topGodEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTopGod_Children() {
		return (EReference) topGodEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOlympusCreature() {
		return olympusCreatureEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOlympusCreature_Hp() {
		return (EAttribute) olympusCreatureEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOlympusCreature_Name() {
		return (EAttribute) olympusCreatureEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOlympusCreature_Power() {
		return (EAttribute) olympusCreatureEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getOlympusCreature__Attack() {
		return olympusCreatureEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSky() {
		return skyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getSky__Attack() {
		return skyEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHell() {
		return hellEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getHell__Attack() {
		return hellEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNormalGod() {
		return normalGodEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getNormalGod_Children() {
		return (EReference) normalGodEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSemiGod() {
		return semiGodEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSemiGod_Weakness() {
		return (EAttribute) semiGodEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOlympus() {
		return olympusEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOlympus_ThereAre() {
		return (EReference) olympusEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MithologyFactory getMithologyFactory() {
		return (MithologyFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		olympusGodEClass = createEClass(OLYMPUS_GOD);
		createEAttribute(olympusGodEClass, OLYMPUS_GOD__NAME);
		createEAttribute(olympusGodEClass, OLYMPUS_GOD__POWER);

		topGodEClass = createEClass(TOP_GOD);
		createEReference(topGodEClass, TOP_GOD__SUBORDINATES);
		createEAttribute(topGodEClass, TOP_GOD__SPECIAL_WEAPON);
		createEReference(topGodEClass, TOP_GOD__CREATES);
		createEReference(topGodEClass, TOP_GOD__CHILDREN);

		olympusCreatureEClass = createEClass(OLYMPUS_CREATURE);
		createEAttribute(olympusCreatureEClass, OLYMPUS_CREATURE__HP);
		createEAttribute(olympusCreatureEClass, OLYMPUS_CREATURE__NAME);
		createEAttribute(olympusCreatureEClass, OLYMPUS_CREATURE__POWER);
		createEOperation(olympusCreatureEClass, OLYMPUS_CREATURE___ATTACK);

		skyEClass = createEClass(SKY);
		createEOperation(skyEClass, SKY___ATTACK);

		hellEClass = createEClass(HELL);
		createEOperation(hellEClass, HELL___ATTACK);

		normalGodEClass = createEClass(NORMAL_GOD);
		createEReference(normalGodEClass, NORMAL_GOD__CHILDREN);

		semiGodEClass = createEClass(SEMI_GOD);
		createEAttribute(semiGodEClass, SEMI_GOD__WEAKNESS);

		olympusEClass = createEClass(OLYMPUS);
		createEReference(olympusEClass, OLYMPUS__THERE_ARE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		topGodEClass.getESuperTypes().add(this.getOlympusGod());
		skyEClass.getESuperTypes().add(this.getOlympusCreature());
		hellEClass.getESuperTypes().add(this.getOlympusCreature());
		normalGodEClass.getESuperTypes().add(this.getOlympusGod());
		semiGodEClass.getESuperTypes().add(this.getOlympusGod());

		// Initialize classes, features, and operations; add parameters
		initEClass(olympusGodEClass, OlympusGod.class, "OlympusGod", IS_ABSTRACT, IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOlympusGod_Name(), ecorePackage.getEString(), "name", null, 0, 1, OlympusGod.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getOlympusGod_Power(), ecorePackage.getEInt(), "power", null, 0, 1, OlympusGod.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(topGodEClass, TopGod.class, "TopGod", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTopGod_Subordinates(), this.getNormalGod(), null, "subordinates", null, 0, -1, TopGod.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTopGod_SpecialWeapon(), ecorePackage.getEString(), "specialWeapon", null, 0, 1, TopGod.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTopGod_Creates(), this.getOlympusCreature(), null, "creates", null, 0, -1, TopGod.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTopGod_Children(), this.getSemiGod(), null, "children", null, 0, -1, TopGod.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(olympusCreatureEClass, OlympusCreature.class, "OlympusCreature", IS_ABSTRACT, IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOlympusCreature_Hp(), ecorePackage.getEIntegerObject(), "hp", null, 0, 1,
				OlympusCreature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getOlympusCreature_Name(), ecorePackage.getEString(), "name", null, 0, 1, OlympusCreature.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getOlympusCreature_Power(), ecorePackage.getEInt(), "power", null, 0, 1, OlympusCreature.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getOlympusCreature__Attack(), ecorePackage.getEInt(), "attack", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(skyEClass, Sky.class, "Sky", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEOperation(getSky__Attack(), ecorePackage.getEInt(), "attack", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(hellEClass, Hell.class, "Hell", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEOperation(getHell__Attack(), ecorePackage.getEInt(), "attack", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(normalGodEClass, NormalGod.class, "NormalGod", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getNormalGod_Children(), this.getSemiGod(), null, "children", null, 0, -1, NormalGod.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(semiGodEClass, SemiGod.class, "SemiGod", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSemiGod_Weakness(), ecorePackage.getEString(), "weakness", null, 0, 1, SemiGod.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(olympusEClass, Olympus.class, "Olympus", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getOlympus_ThereAre(), this.getOlympusGod(), null, "thereAre", null, 0, -1, Olympus.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //MithologyPackageImpl
