/**
 */
package org.dat355.rafa.mithology.impl;

import java.util.Collection;

import org.dat355.rafa.mithology.MithologyPackage;
import org.dat355.rafa.mithology.NormalGod;
import org.dat355.rafa.mithology.OlympusCreature;
import org.dat355.rafa.mithology.SemiGod;
import org.dat355.rafa.mithology.TopGod;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Top God</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.impl.TopGodImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.TopGodImpl#getPower <em>Power</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.TopGodImpl#getSubordinates <em>Subordinates</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.TopGodImpl#getSpecialWeapon <em>Special Weapon</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.TopGodImpl#getCreates <em>Creates</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.TopGodImpl#getChildren <em>Children</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TopGodImpl extends MinimalEObjectImpl.Container implements TopGod {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPower() <em>Power</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPower()
	 * @generated
	 * @ordered
	 */
	protected static final int POWER_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPower() <em>Power</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPower()
	 * @generated
	 * @ordered
	 */
	protected int power = POWER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSubordinates() <em>Subordinates</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubordinates()
	 * @generated
	 * @ordered
	 */
	protected EList<NormalGod> subordinates;

	/**
	 * The default value of the '{@link #getSpecialWeapon() <em>Special Weapon</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpecialWeapon()
	 * @generated
	 * @ordered
	 */
	protected static final String SPECIAL_WEAPON_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSpecialWeapon() <em>Special Weapon</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpecialWeapon()
	 * @generated
	 * @ordered
	 */
	protected String specialWeapon = SPECIAL_WEAPON_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCreates() <em>Creates</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCreates()
	 * @generated
	 * @ordered
	 */
	protected EList<OlympusCreature> creates;

	/**
	 * The cached value of the '{@link #getChildren() <em>Children</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChildren()
	 * @generated
	 * @ordered
	 */
	protected EList<SemiGod> children;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TopGodImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MithologyPackage.Literals.TOP_GOD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MithologyPackage.TOP_GOD__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPower() {
		return power;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPower(int newPower) {
		int oldPower = power;
		power = newPower;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MithologyPackage.TOP_GOD__POWER, oldPower, power));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<NormalGod> getSubordinates() {
		if (subordinates == null) {
			subordinates = new EObjectContainmentEList<NormalGod>(NormalGod.class, this,
					MithologyPackage.TOP_GOD__SUBORDINATES);
		}
		return subordinates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSpecialWeapon() {
		return specialWeapon;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSpecialWeapon(String newSpecialWeapon) {
		String oldSpecialWeapon = specialWeapon;
		specialWeapon = newSpecialWeapon;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MithologyPackage.TOP_GOD__SPECIAL_WEAPON,
					oldSpecialWeapon, specialWeapon));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<OlympusCreature> getCreates() {
		if (creates == null) {
			creates = new EObjectContainmentEList<OlympusCreature>(OlympusCreature.class, this,
					MithologyPackage.TOP_GOD__CREATES);
		}
		return creates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SemiGod> getChildren() {
		if (children == null) {
			children = new EObjectContainmentEList<SemiGod>(SemiGod.class, this, MithologyPackage.TOP_GOD__CHILDREN);
		}
		return children;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MithologyPackage.TOP_GOD__SUBORDINATES:
			return ((InternalEList<?>) getSubordinates()).basicRemove(otherEnd, msgs);
		case MithologyPackage.TOP_GOD__CREATES:
			return ((InternalEList<?>) getCreates()).basicRemove(otherEnd, msgs);
		case MithologyPackage.TOP_GOD__CHILDREN:
			return ((InternalEList<?>) getChildren()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MithologyPackage.TOP_GOD__NAME:
			return getName();
		case MithologyPackage.TOP_GOD__POWER:
			return getPower();
		case MithologyPackage.TOP_GOD__SUBORDINATES:
			return getSubordinates();
		case MithologyPackage.TOP_GOD__SPECIAL_WEAPON:
			return getSpecialWeapon();
		case MithologyPackage.TOP_GOD__CREATES:
			return getCreates();
		case MithologyPackage.TOP_GOD__CHILDREN:
			return getChildren();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MithologyPackage.TOP_GOD__NAME:
			setName((String) newValue);
			return;
		case MithologyPackage.TOP_GOD__POWER:
			setPower((Integer) newValue);
			return;
		case MithologyPackage.TOP_GOD__SUBORDINATES:
			getSubordinates().clear();
			getSubordinates().addAll((Collection<? extends NormalGod>) newValue);
			return;
		case MithologyPackage.TOP_GOD__SPECIAL_WEAPON:
			setSpecialWeapon((String) newValue);
			return;
		case MithologyPackage.TOP_GOD__CREATES:
			getCreates().clear();
			getCreates().addAll((Collection<? extends OlympusCreature>) newValue);
			return;
		case MithologyPackage.TOP_GOD__CHILDREN:
			getChildren().clear();
			getChildren().addAll((Collection<? extends SemiGod>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MithologyPackage.TOP_GOD__NAME:
			setName(NAME_EDEFAULT);
			return;
		case MithologyPackage.TOP_GOD__POWER:
			setPower(POWER_EDEFAULT);
			return;
		case MithologyPackage.TOP_GOD__SUBORDINATES:
			getSubordinates().clear();
			return;
		case MithologyPackage.TOP_GOD__SPECIAL_WEAPON:
			setSpecialWeapon(SPECIAL_WEAPON_EDEFAULT);
			return;
		case MithologyPackage.TOP_GOD__CREATES:
			getCreates().clear();
			return;
		case MithologyPackage.TOP_GOD__CHILDREN:
			getChildren().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MithologyPackage.TOP_GOD__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case MithologyPackage.TOP_GOD__POWER:
			return power != POWER_EDEFAULT;
		case MithologyPackage.TOP_GOD__SUBORDINATES:
			return subordinates != null && !subordinates.isEmpty();
		case MithologyPackage.TOP_GOD__SPECIAL_WEAPON:
			return SPECIAL_WEAPON_EDEFAULT == null ? specialWeapon != null
					: !SPECIAL_WEAPON_EDEFAULT.equals(specialWeapon);
		case MithologyPackage.TOP_GOD__CREATES:
			return creates != null && !creates.isEmpty();
		case MithologyPackage.TOP_GOD__CHILDREN:
			return children != null && !children.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", power: ");
		result.append(power);
		result.append(", specialWeapon: ");
		result.append(specialWeapon);
		result.append(')');
		return result.toString();
	}

} //TopGodImpl
