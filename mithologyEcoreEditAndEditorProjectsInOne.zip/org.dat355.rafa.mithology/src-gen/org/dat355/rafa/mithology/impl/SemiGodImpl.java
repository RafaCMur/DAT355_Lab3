/**
 */
package org.dat355.rafa.mithology.impl;

import org.dat355.rafa.mithology.MithologyPackage;
import org.dat355.rafa.mithology.SemiGod;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Semi God</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.impl.SemiGodImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.SemiGodImpl#getPower <em>Power</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.SemiGodImpl#getWeakness <em>Weakness</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SemiGodImpl extends MinimalEObjectImpl.Container implements SemiGod {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPower() <em>Power</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPower()
	 * @generated
	 * @ordered
	 */
	protected static final int POWER_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPower() <em>Power</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPower()
	 * @generated
	 * @ordered
	 */
	protected int power = POWER_EDEFAULT;

	/**
	 * The default value of the '{@link #getWeakness() <em>Weakness</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeakness()
	 * @generated
	 * @ordered
	 */
	protected static final String WEAKNESS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getWeakness() <em>Weakness</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeakness()
	 * @generated
	 * @ordered
	 */
	protected String weakness = WEAKNESS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SemiGodImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MithologyPackage.Literals.SEMI_GOD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MithologyPackage.SEMI_GOD__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPower() {
		return power;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPower(int newPower) {
		int oldPower = power;
		power = newPower;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MithologyPackage.SEMI_GOD__POWER, oldPower, power));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getWeakness() {
		return weakness;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWeakness(String newWeakness) {
		String oldWeakness = weakness;
		weakness = newWeakness;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MithologyPackage.SEMI_GOD__WEAKNESS, oldWeakness,
					weakness));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MithologyPackage.SEMI_GOD__NAME:
			return getName();
		case MithologyPackage.SEMI_GOD__POWER:
			return getPower();
		case MithologyPackage.SEMI_GOD__WEAKNESS:
			return getWeakness();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MithologyPackage.SEMI_GOD__NAME:
			setName((String) newValue);
			return;
		case MithologyPackage.SEMI_GOD__POWER:
			setPower((Integer) newValue);
			return;
		case MithologyPackage.SEMI_GOD__WEAKNESS:
			setWeakness((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MithologyPackage.SEMI_GOD__NAME:
			setName(NAME_EDEFAULT);
			return;
		case MithologyPackage.SEMI_GOD__POWER:
			setPower(POWER_EDEFAULT);
			return;
		case MithologyPackage.SEMI_GOD__WEAKNESS:
			setWeakness(WEAKNESS_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MithologyPackage.SEMI_GOD__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case MithologyPackage.SEMI_GOD__POWER:
			return power != POWER_EDEFAULT;
		case MithologyPackage.SEMI_GOD__WEAKNESS:
			return WEAKNESS_EDEFAULT == null ? weakness != null : !WEAKNESS_EDEFAULT.equals(weakness);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", power: ");
		result.append(power);
		result.append(", weakness: ");
		result.append(weakness);
		result.append(')');
		return result.toString();
	}

} //SemiGodImpl
