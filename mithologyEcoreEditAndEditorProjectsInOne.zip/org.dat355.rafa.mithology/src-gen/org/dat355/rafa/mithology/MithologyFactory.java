/**
 */
package org.dat355.rafa.mithology;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.dat355.rafa.mithology.MithologyPackage
 * @generated
 */
public interface MithologyFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MithologyFactory eINSTANCE = org.dat355.rafa.mithology.impl.MithologyFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Top God</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Top God</em>'.
	 * @generated
	 */
	TopGod createTopGod();

	/**
	 * Returns a new object of class '<em>Sky</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sky</em>'.
	 * @generated
	 */
	Sky createSky();

	/**
	 * Returns a new object of class '<em>Hell</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hell</em>'.
	 * @generated
	 */
	Hell createHell();

	/**
	 * Returns a new object of class '<em>Normal God</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Normal God</em>'.
	 * @generated
	 */
	NormalGod createNormalGod();

	/**
	 * Returns a new object of class '<em>Semi God</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Semi God</em>'.
	 * @generated
	 */
	SemiGod createSemiGod();

	/**
	 * Returns a new object of class '<em>Olympus</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Olympus</em>'.
	 * @generated
	 */
	Olympus createOlympus();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	MithologyPackage getMithologyPackage();

} //MithologyFactory
