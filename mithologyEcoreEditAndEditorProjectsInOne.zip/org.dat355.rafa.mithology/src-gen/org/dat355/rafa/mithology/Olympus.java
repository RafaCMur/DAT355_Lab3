/**
 */
package org.dat355.rafa.mithology;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Olympus</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.Olympus#getThereAre <em>There Are</em>}</li>
 * </ul>
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getOlympus()
 * @model
 * @generated
 */
public interface Olympus extends EObject {
	/**
	 * Returns the value of the '<em><b>There Are</b></em>' containment reference list.
	 * The list contents are of type {@link org.dat355.rafa.mithology.OlympusGod}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>There Are</em>' containment reference list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getOlympus_ThereAre()
	 * @model containment="true"
	 * @generated
	 */
	EList<OlympusGod> getThereAre();

} // Olympus
