/**
 */
package org.dat355.rafa.mithology.util;

import org.dat355.rafa.mithology.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see org.dat355.rafa.mithology.MithologyPackage
 * @generated
 */
public class MithologySwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static MithologyPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MithologySwitch() {
		if (modelPackage == null) {
			modelPackage = MithologyPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case MithologyPackage.OLYMPUS_GOD: {
			OlympusGod olympusGod = (OlympusGod) theEObject;
			T result = caseOlympusGod(olympusGod);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MithologyPackage.TOP_GOD: {
			TopGod topGod = (TopGod) theEObject;
			T result = caseTopGod(topGod);
			if (result == null)
				result = caseOlympusGod(topGod);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MithologyPackage.OLYMPUS_CREATURE: {
			OlympusCreature olympusCreature = (OlympusCreature) theEObject;
			T result = caseOlympusCreature(olympusCreature);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MithologyPackage.SKY: {
			Sky sky = (Sky) theEObject;
			T result = caseSky(sky);
			if (result == null)
				result = caseOlympusCreature(sky);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MithologyPackage.HELL: {
			Hell hell = (Hell) theEObject;
			T result = caseHell(hell);
			if (result == null)
				result = caseOlympusCreature(hell);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MithologyPackage.NORMAL_GOD: {
			NormalGod normalGod = (NormalGod) theEObject;
			T result = caseNormalGod(normalGod);
			if (result == null)
				result = caseOlympusGod(normalGod);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MithologyPackage.SEMI_GOD: {
			SemiGod semiGod = (SemiGod) theEObject;
			T result = caseSemiGod(semiGod);
			if (result == null)
				result = caseOlympusGod(semiGod);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MithologyPackage.OLYMPUS: {
			Olympus olympus = (Olympus) theEObject;
			T result = caseOlympus(olympus);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Olympus God</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Olympus God</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOlympusGod(OlympusGod object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Top God</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Top God</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTopGod(TopGod object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Olympus Creature</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Olympus Creature</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOlympusCreature(OlympusCreature object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sky</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sky</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSky(Sky object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Hell</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Hell</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHell(Hell object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Normal God</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Normal God</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNormalGod(NormalGod object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Semi God</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Semi God</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSemiGod(SemiGod object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Olympus</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Olympus</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOlympus(Olympus object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //MithologySwitch
