/**
 */
package org.dat355.rafa.mithology;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Top God</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.TopGod#getSubordinates <em>Subordinates</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.TopGod#getSpecialWeapon <em>Special Weapon</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.TopGod#getCreates <em>Creates</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.TopGod#getChildren <em>Children</em>}</li>
 * </ul>
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getTopGod()
 * @model
 * @generated
 */
public interface TopGod extends OlympusGod {
	/**
	 * Returns the value of the '<em><b>Subordinates</b></em>' containment reference list.
	 * The list contents are of type {@link org.dat355.rafa.mithology.NormalGod}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subordinates</em>' containment reference list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getTopGod_Subordinates()
	 * @model containment="true"
	 * @generated
	 */
	EList<NormalGod> getSubordinates();

	/**
	 * Returns the value of the '<em><b>Special Weapon</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Special Weapon</em>' attribute.
	 * @see #setSpecialWeapon(String)
	 * @see org.dat355.rafa.mithology.MithologyPackage#getTopGod_SpecialWeapon()
	 * @model
	 * @generated
	 */
	String getSpecialWeapon();

	/**
	 * Sets the value of the '{@link org.dat355.rafa.mithology.TopGod#getSpecialWeapon <em>Special Weapon</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Special Weapon</em>' attribute.
	 * @see #getSpecialWeapon()
	 * @generated
	 */
	void setSpecialWeapon(String value);

	/**
	 * Returns the value of the '<em><b>Creates</b></em>' containment reference list.
	 * The list contents are of type {@link org.dat355.rafa.mithology.OlympusCreature}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Creates</em>' containment reference list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getTopGod_Creates()
	 * @model containment="true"
	 * @generated
	 */
	EList<OlympusCreature> getCreates();

	/**
	 * Returns the value of the '<em><b>Children</b></em>' containment reference list.
	 * The list contents are of type {@link org.dat355.rafa.mithology.SemiGod}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Children</em>' containment reference list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getTopGod_Children()
	 * @model containment="true"
	 * @generated
	 */
	EList<SemiGod> getChildren();

} // TopGod
