/**
 */
package org.dat355.rafa.mithology;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Semi God</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.SemiGod#getWeakness <em>Weakness</em>}</li>
 * </ul>
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getSemiGod()
 * @model
 * @generated
 */
public interface SemiGod extends OlympusGod {
	/**
	 * Returns the value of the '<em><b>Weakness</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Weakness</em>' attribute.
	 * @see #setWeakness(String)
	 * @see org.dat355.rafa.mithology.MithologyPackage#getSemiGod_Weakness()
	 * @model
	 * @generated
	 */
	String getWeakness();

	/**
	 * Sets the value of the '{@link org.dat355.rafa.mithology.SemiGod#getWeakness <em>Weakness</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Weakness</em>' attribute.
	 * @see #getWeakness()
	 * @generated
	 */
	void setWeakness(String value);

} // SemiGod
