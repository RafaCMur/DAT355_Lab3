/**
 */
package org.dat355.rafa.mithology;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Normal God</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getNormalGod()
 * @model
 * @generated
 */
public interface NormalGod extends RealGod {
} // NormalGod
