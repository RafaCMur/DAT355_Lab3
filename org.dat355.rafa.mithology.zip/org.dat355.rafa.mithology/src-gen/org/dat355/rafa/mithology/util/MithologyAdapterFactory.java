/**
 */
package org.dat355.rafa.mithology.util;

import org.dat355.rafa.mithology.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see org.dat355.rafa.mithology.MithologyPackage
 * @generated
 */
public class MithologyAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static MithologyPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MithologyAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = MithologyPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MithologySwitch<Adapter> modelSwitch = new MithologySwitch<Adapter>() {
		@Override
		public Adapter caseOlympusGod(OlympusGod object) {
			return createOlympusGodAdapter();
		}

		@Override
		public Adapter caseTopGod(TopGod object) {
			return createTopGodAdapter();
		}

		@Override
		public Adapter caseOlympusCreature(OlympusCreature object) {
			return createOlympusCreatureAdapter();
		}

		@Override
		public Adapter caseSky(Sky object) {
			return createSkyAdapter();
		}

		@Override
		public Adapter caseHell(Hell object) {
			return createHellAdapter();
		}

		@Override
		public Adapter caseNormalGod(NormalGod object) {
			return createNormalGodAdapter();
		}

		@Override
		public Adapter caseSemiGod(SemiGod object) {
			return createSemiGodAdapter();
		}

		@Override
		public Adapter caseOlympus(Olympus object) {
			return createOlympusAdapter();
		}

		@Override
		public Adapter caseRealGod(RealGod object) {
			return createRealGodAdapter();
		}

		@Override
		public Adapter caseSpecialWeapon(SpecialWeapon object) {
			return createSpecialWeaponAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.dat355.rafa.mithology.OlympusGod <em>Olympus God</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.dat355.rafa.mithology.OlympusGod
	 * @generated
	 */
	public Adapter createOlympusGodAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.dat355.rafa.mithology.TopGod <em>Top God</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.dat355.rafa.mithology.TopGod
	 * @generated
	 */
	public Adapter createTopGodAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.dat355.rafa.mithology.OlympusCreature <em>Olympus Creature</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.dat355.rafa.mithology.OlympusCreature
	 * @generated
	 */
	public Adapter createOlympusCreatureAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.dat355.rafa.mithology.Sky <em>Sky</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.dat355.rafa.mithology.Sky
	 * @generated
	 */
	public Adapter createSkyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.dat355.rafa.mithology.Hell <em>Hell</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.dat355.rafa.mithology.Hell
	 * @generated
	 */
	public Adapter createHellAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.dat355.rafa.mithology.NormalGod <em>Normal God</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.dat355.rafa.mithology.NormalGod
	 * @generated
	 */
	public Adapter createNormalGodAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.dat355.rafa.mithology.SemiGod <em>Semi God</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.dat355.rafa.mithology.SemiGod
	 * @generated
	 */
	public Adapter createSemiGodAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.dat355.rafa.mithology.Olympus <em>Olympus</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.dat355.rafa.mithology.Olympus
	 * @generated
	 */
	public Adapter createOlympusAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.dat355.rafa.mithology.RealGod <em>Real God</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.dat355.rafa.mithology.RealGod
	 * @generated
	 */
	public Adapter createRealGodAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.dat355.rafa.mithology.SpecialWeapon <em>Special Weapon</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.dat355.rafa.mithology.SpecialWeapon
	 * @generated
	 */
	public Adapter createSpecialWeaponAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //MithologyAdapterFactory
