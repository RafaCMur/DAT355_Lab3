/**
 */
package org.dat355.rafa.mithology;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Special Weapon</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.SpecialWeapon#getName <em>Name</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.SpecialWeapon#getPowerIncrement <em>Power Increment</em>}</li>
 * </ul>
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getSpecialWeapon()
 * @model
 * @generated
 */
public interface SpecialWeapon extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.dat355.rafa.mithology.MithologyPackage#getSpecialWeapon_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.dat355.rafa.mithology.SpecialWeapon#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Power Increment</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Power Increment</em>' attribute list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getSpecialWeapon_PowerIncrement()
	 * @model lower="5" upper="15"
	 * @generated
	 */
	EList<Integer> getPowerIncrement();

} // SpecialWeapon
