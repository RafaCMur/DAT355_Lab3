/**
 */
package org.dat355.rafa.mithology.impl;

import java.util.Collection;

import org.dat355.rafa.mithology.MithologyPackage;
import org.dat355.rafa.mithology.OlympusCreature;
import org.dat355.rafa.mithology.RealGod;
import org.dat355.rafa.mithology.SemiGod;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Real God</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.impl.RealGodImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.RealGodImpl#getCanCreate <em>Can Create</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.RealGodImpl#getChildren <em>Children</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.RealGodImpl#getHP <em>HP</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.RealGodImpl#getPower <em>Power</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class RealGodImpl extends MinimalEObjectImpl.Container implements RealGod {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCanCreate() <em>Can Create</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCanCreate()
	 * @generated
	 * @ordered
	 */
	protected EList<OlympusCreature> canCreate;

	/**
	 * The cached value of the '{@link #getChildren() <em>Children</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChildren()
	 * @generated
	 * @ordered
	 */
	protected EList<SemiGod> children;

	/**
	 * The cached value of the '{@link #getHP() <em>HP</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHP()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> hp;

	/**
	 * The cached value of the '{@link #getPower() <em>Power</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPower()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> power;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RealGodImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MithologyPackage.Literals.REAL_GOD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MithologyPackage.REAL_GOD__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<OlympusCreature> getCanCreate() {
		if (canCreate == null) {
			canCreate = new EObjectContainmentEList<OlympusCreature>(OlympusCreature.class, this,
					MithologyPackage.REAL_GOD__CAN_CREATE);
		}
		return canCreate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SemiGod> getChildren() {
		if (children == null) {
			children = new EObjectWithInverseResolvingEList.ManyInverse<SemiGod>(SemiGod.class, this,
					MithologyPackage.REAL_GOD__CHILDREN, MithologyPackage.SEMI_GOD__PARENTS);
		}
		return children;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Integer> getHP() {
		if (hp == null) {
			hp = new EDataTypeUniqueEList<Integer>(Integer.class, this, MithologyPackage.REAL_GOD__HP);
		}
		return hp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Integer> getPower() {
		if (power == null) {
			power = new EDataTypeUniqueEList<Integer>(Integer.class, this, MithologyPackage.REAL_GOD__POWER);
		}
		return power;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MithologyPackage.REAL_GOD__CHILDREN:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getChildren()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MithologyPackage.REAL_GOD__CAN_CREATE:
			return ((InternalEList<?>) getCanCreate()).basicRemove(otherEnd, msgs);
		case MithologyPackage.REAL_GOD__CHILDREN:
			return ((InternalEList<?>) getChildren()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MithologyPackage.REAL_GOD__NAME:
			return getName();
		case MithologyPackage.REAL_GOD__CAN_CREATE:
			return getCanCreate();
		case MithologyPackage.REAL_GOD__CHILDREN:
			return getChildren();
		case MithologyPackage.REAL_GOD__HP:
			return getHP();
		case MithologyPackage.REAL_GOD__POWER:
			return getPower();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MithologyPackage.REAL_GOD__NAME:
			setName((String) newValue);
			return;
		case MithologyPackage.REAL_GOD__CAN_CREATE:
			getCanCreate().clear();
			getCanCreate().addAll((Collection<? extends OlympusCreature>) newValue);
			return;
		case MithologyPackage.REAL_GOD__CHILDREN:
			getChildren().clear();
			getChildren().addAll((Collection<? extends SemiGod>) newValue);
			return;
		case MithologyPackage.REAL_GOD__HP:
			getHP().clear();
			getHP().addAll((Collection<? extends Integer>) newValue);
			return;
		case MithologyPackage.REAL_GOD__POWER:
			getPower().clear();
			getPower().addAll((Collection<? extends Integer>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MithologyPackage.REAL_GOD__NAME:
			setName(NAME_EDEFAULT);
			return;
		case MithologyPackage.REAL_GOD__CAN_CREATE:
			getCanCreate().clear();
			return;
		case MithologyPackage.REAL_GOD__CHILDREN:
			getChildren().clear();
			return;
		case MithologyPackage.REAL_GOD__HP:
			getHP().clear();
			return;
		case MithologyPackage.REAL_GOD__POWER:
			getPower().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MithologyPackage.REAL_GOD__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case MithologyPackage.REAL_GOD__CAN_CREATE:
			return canCreate != null && !canCreate.isEmpty();
		case MithologyPackage.REAL_GOD__CHILDREN:
			return children != null && !children.isEmpty();
		case MithologyPackage.REAL_GOD__HP:
			return hp != null && !hp.isEmpty();
		case MithologyPackage.REAL_GOD__POWER:
			return power != null && !power.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", HP: ");
		result.append(hp);
		result.append(", power: ");
		result.append(power);
		result.append(')');
		return result.toString();
	}

} //RealGodImpl
