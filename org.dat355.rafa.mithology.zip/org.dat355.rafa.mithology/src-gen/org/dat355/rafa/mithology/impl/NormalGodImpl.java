/**
 */
package org.dat355.rafa.mithology.impl;

import org.dat355.rafa.mithology.MithologyPackage;
import org.dat355.rafa.mithology.NormalGod;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Normal God</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class NormalGodImpl extends RealGodImpl implements NormalGod {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NormalGodImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MithologyPackage.Literals.NORMAL_GOD;
	}

} //NormalGodImpl
