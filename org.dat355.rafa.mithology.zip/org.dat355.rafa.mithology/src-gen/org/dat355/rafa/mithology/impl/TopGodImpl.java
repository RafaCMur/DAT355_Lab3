/**
 */
package org.dat355.rafa.mithology.impl;

import java.util.Collection;

import org.dat355.rafa.mithology.MithologyPackage;
import org.dat355.rafa.mithology.NormalGod;
import org.dat355.rafa.mithology.SpecialWeapon;
import org.dat355.rafa.mithology.TopGod;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Top God</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.impl.TopGodImpl#getSubordinates <em>Subordinates</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.TopGodImpl#getOwns <em>Owns</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TopGodImpl extends RealGodImpl implements TopGod {
	/**
	 * The cached value of the '{@link #getSubordinates() <em>Subordinates</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubordinates()
	 * @generated
	 * @ordered
	 */
	protected EList<NormalGod> subordinates;

	/**
	 * The cached value of the '{@link #getOwns() <em>Owns</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwns()
	 * @generated
	 * @ordered
	 */
	protected SpecialWeapon owns;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TopGodImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MithologyPackage.Literals.TOP_GOD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<NormalGod> getSubordinates() {
		if (subordinates == null) {
			subordinates = new EObjectContainmentEList<NormalGod>(NormalGod.class, this,
					MithologyPackage.TOP_GOD__SUBORDINATES);
		}
		return subordinates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SpecialWeapon getOwns() {
		if (owns != null && owns.eIsProxy()) {
			InternalEObject oldOwns = (InternalEObject) owns;
			owns = (SpecialWeapon) eResolveProxy(oldOwns);
			if (owns != oldOwns) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MithologyPackage.TOP_GOD__OWNS, oldOwns,
							owns));
			}
		}
		return owns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SpecialWeapon basicGetOwns() {
		return owns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOwns(SpecialWeapon newOwns) {
		SpecialWeapon oldOwns = owns;
		owns = newOwns;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MithologyPackage.TOP_GOD__OWNS, oldOwns, owns));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MithologyPackage.TOP_GOD__SUBORDINATES:
			return ((InternalEList<?>) getSubordinates()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MithologyPackage.TOP_GOD__SUBORDINATES:
			return getSubordinates();
		case MithologyPackage.TOP_GOD__OWNS:
			if (resolve)
				return getOwns();
			return basicGetOwns();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MithologyPackage.TOP_GOD__SUBORDINATES:
			getSubordinates().clear();
			getSubordinates().addAll((Collection<? extends NormalGod>) newValue);
			return;
		case MithologyPackage.TOP_GOD__OWNS:
			setOwns((SpecialWeapon) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MithologyPackage.TOP_GOD__SUBORDINATES:
			getSubordinates().clear();
			return;
		case MithologyPackage.TOP_GOD__OWNS:
			setOwns((SpecialWeapon) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MithologyPackage.TOP_GOD__SUBORDINATES:
			return subordinates != null && !subordinates.isEmpty();
		case MithologyPackage.TOP_GOD__OWNS:
			return owns != null;
		}
		return super.eIsSet(featureID);
	}

} //TopGodImpl
