/**
 */
package org.dat355.rafa.mithology.impl;

import org.dat355.rafa.mithology.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MithologyFactoryImpl extends EFactoryImpl implements MithologyFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static MithologyFactory init() {
		try {
			MithologyFactory theMithologyFactory = (MithologyFactory) EPackage.Registry.INSTANCE
					.getEFactory(MithologyPackage.eNS_URI);
			if (theMithologyFactory != null) {
				return theMithologyFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new MithologyFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MithologyFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case MithologyPackage.TOP_GOD:
			return createTopGod();
		case MithologyPackage.SKY:
			return createSky();
		case MithologyPackage.HELL:
			return createHell();
		case MithologyPackage.NORMAL_GOD:
			return createNormalGod();
		case MithologyPackage.OLYMPUS:
			return createOlympus();
		case MithologyPackage.SPECIAL_WEAPON:
			return createSpecialWeapon();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TopGod createTopGod() {
		TopGodImpl topGod = new TopGodImpl();
		return topGod;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Sky createSky() {
		SkyImpl sky = new SkyImpl();
		return sky;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Hell createHell() {
		HellImpl hell = new HellImpl();
		return hell;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NormalGod createNormalGod() {
		NormalGodImpl normalGod = new NormalGodImpl();
		return normalGod;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Olympus createOlympus() {
		OlympusImpl olympus = new OlympusImpl();
		return olympus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SpecialWeapon createSpecialWeapon() {
		SpecialWeaponImpl specialWeapon = new SpecialWeaponImpl();
		return specialWeapon;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MithologyPackage getMithologyPackage() {
		return (MithologyPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static MithologyPackage getPackage() {
		return MithologyPackage.eINSTANCE;
	}

} //MithologyFactoryImpl
