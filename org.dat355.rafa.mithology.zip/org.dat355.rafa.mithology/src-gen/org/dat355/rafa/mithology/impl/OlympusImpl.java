/**
 */
package org.dat355.rafa.mithology.impl;

import java.util.Collection;

import org.dat355.rafa.mithology.MithologyPackage;
import org.dat355.rafa.mithology.Olympus;
import org.dat355.rafa.mithology.OlympusCreature;
import org.dat355.rafa.mithology.OlympusGod;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Olympus</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.impl.OlympusImpl#getThereAre <em>There Are</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.OlympusImpl#getThereExist <em>There Exist</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OlympusImpl extends MinimalEObjectImpl.Container implements Olympus {
	/**
	 * The cached value of the '{@link #getThereAre() <em>There Are</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThereAre()
	 * @generated
	 * @ordered
	 */
	protected EList<OlympusGod> thereAre;

	/**
	 * The cached value of the '{@link #getThereExist() <em>There Exist</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThereExist()
	 * @generated
	 * @ordered
	 */
	protected EList<OlympusCreature> thereExist;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OlympusImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MithologyPackage.Literals.OLYMPUS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<OlympusGod> getThereAre() {
		if (thereAre == null) {
			thereAre = new EObjectContainmentEList<OlympusGod>(OlympusGod.class, this,
					MithologyPackage.OLYMPUS__THERE_ARE);
		}
		return thereAre;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<OlympusCreature> getThereExist() {
		if (thereExist == null) {
			thereExist = new EObjectContainmentEList<OlympusCreature>(OlympusCreature.class, this,
					MithologyPackage.OLYMPUS__THERE_EXIST);
		}
		return thereExist;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MithologyPackage.OLYMPUS__THERE_ARE:
			return ((InternalEList<?>) getThereAre()).basicRemove(otherEnd, msgs);
		case MithologyPackage.OLYMPUS__THERE_EXIST:
			return ((InternalEList<?>) getThereExist()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MithologyPackage.OLYMPUS__THERE_ARE:
			return getThereAre();
		case MithologyPackage.OLYMPUS__THERE_EXIST:
			return getThereExist();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MithologyPackage.OLYMPUS__THERE_ARE:
			getThereAre().clear();
			getThereAre().addAll((Collection<? extends OlympusGod>) newValue);
			return;
		case MithologyPackage.OLYMPUS__THERE_EXIST:
			getThereExist().clear();
			getThereExist().addAll((Collection<? extends OlympusCreature>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MithologyPackage.OLYMPUS__THERE_ARE:
			getThereAre().clear();
			return;
		case MithologyPackage.OLYMPUS__THERE_EXIST:
			getThereExist().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MithologyPackage.OLYMPUS__THERE_ARE:
			return thereAre != null && !thereAre.isEmpty();
		case MithologyPackage.OLYMPUS__THERE_EXIST:
			return thereExist != null && !thereExist.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //OlympusImpl
