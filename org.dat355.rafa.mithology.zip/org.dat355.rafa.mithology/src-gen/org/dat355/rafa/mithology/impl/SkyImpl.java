/**
 */
package org.dat355.rafa.mithology.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.dat355.rafa.mithology.MithologyPackage;
import org.dat355.rafa.mithology.Sky;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sky</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.impl.SkyImpl#getHP <em>HP</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.SkyImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.impl.SkyImpl#getPower <em>Power</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SkyImpl extends MinimalEObjectImpl.Container implements Sky {
	/**
	 * The cached value of the '{@link #getHP() <em>HP</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHP()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> hp;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPower() <em>Power</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPower()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> power;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SkyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MithologyPackage.Literals.SKY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Integer> getHP() {
		if (hp == null) {
			hp = new EDataTypeUniqueEList<Integer>(Integer.class, this, MithologyPackage.SKY__HP);
		}
		return hp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MithologyPackage.SKY__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Integer> getPower() {
		if (power == null) {
			power = new EDataTypeUniqueEList<Integer>(Integer.class, this, MithologyPackage.SKY__POWER);
		}
		return power;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int attack() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MithologyPackage.SKY__HP:
			return getHP();
		case MithologyPackage.SKY__NAME:
			return getName();
		case MithologyPackage.SKY__POWER:
			return getPower();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MithologyPackage.SKY__HP:
			getHP().clear();
			getHP().addAll((Collection<? extends Integer>) newValue);
			return;
		case MithologyPackage.SKY__NAME:
			setName((String) newValue);
			return;
		case MithologyPackage.SKY__POWER:
			getPower().clear();
			getPower().addAll((Collection<? extends Integer>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MithologyPackage.SKY__HP:
			getHP().clear();
			return;
		case MithologyPackage.SKY__NAME:
			setName(NAME_EDEFAULT);
			return;
		case MithologyPackage.SKY__POWER:
			getPower().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MithologyPackage.SKY__HP:
			return hp != null && !hp.isEmpty();
		case MithologyPackage.SKY__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case MithologyPackage.SKY__POWER:
			return power != null && !power.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case MithologyPackage.SKY___ATTACK:
			return attack();
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (HP: ");
		result.append(hp);
		result.append(", name: ");
		result.append(name);
		result.append(", power: ");
		result.append(power);
		result.append(')');
		return result.toString();
	}

} //SkyImpl
