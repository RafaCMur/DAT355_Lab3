/**
 */
package org.dat355.rafa.mithology;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Olympus Creature</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.OlympusCreature#getHP <em>HP</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.OlympusCreature#getName <em>Name</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.OlympusCreature#getPower <em>Power</em>}</li>
 * </ul>
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getOlympusCreature()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface OlympusCreature extends EObject {
	/**
	 * Returns the value of the '<em><b>HP</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>HP</em>' attribute list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getOlympusCreature_HP()
	 * @model upper="100"
	 * @generated
	 */
	EList<Integer> getHP();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.dat355.rafa.mithology.MithologyPackage#getOlympusCreature_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.dat355.rafa.mithology.OlympusCreature#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Power</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Power</em>' attribute list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getOlympusCreature_Power()
	 * @model required="true" upper="10"
	 * @generated
	 */
	EList<Integer> getPower();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	int attack();

} // OlympusCreature
