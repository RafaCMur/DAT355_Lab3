/**
 */
package org.dat355.rafa.mithology;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Semi God</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.SemiGod#getWeakness <em>Weakness</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.SemiGod#getParents <em>Parents</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.SemiGod#getHP <em>HP</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.SemiGod#getPower <em>Power</em>}</li>
 * </ul>
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getSemiGod()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SemiGod extends OlympusGod {
	/**
	 * Returns the value of the '<em><b>Weakness</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Weakness</em>' attribute.
	 * @see #setWeakness(String)
	 * @see org.dat355.rafa.mithology.MithologyPackage#getSemiGod_Weakness()
	 * @model
	 * @generated
	 */
	String getWeakness();

	/**
	 * Sets the value of the '{@link org.dat355.rafa.mithology.SemiGod#getWeakness <em>Weakness</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Weakness</em>' attribute.
	 * @see #getWeakness()
	 * @generated
	 */
	void setWeakness(String value);

	/**
	 * Returns the value of the '<em><b>Parents</b></em>' reference list.
	 * The list contents are of type {@link org.dat355.rafa.mithology.RealGod}.
	 * It is bidirectional and its opposite is '{@link org.dat355.rafa.mithology.RealGod#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parents</em>' reference list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getSemiGod_Parents()
	 * @see org.dat355.rafa.mithology.RealGod#getChildren
	 * @model opposite="children" required="true"
	 * @generated
	 */
	EList<RealGod> getParents();

	/**
	 * Returns the value of the '<em><b>HP</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>HP</em>' attribute list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getSemiGod_HP()
	 * @model upper="200"
	 * @generated
	 */
	EList<Integer> getHP();

	/**
	 * Returns the value of the '<em><b>Power</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Power</em>' attribute list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getSemiGod_Power()
	 * @model lower="5" upper="20"
	 * @generated
	 */
	EList<Integer> getPower();

} // SemiGod
