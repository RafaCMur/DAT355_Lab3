/**
 */
package org.dat355.rafa.mithology;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Real God</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.RealGod#getCanCreate <em>Can Create</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.RealGod#getChildren <em>Children</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.RealGod#getHP <em>HP</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.RealGod#getPower <em>Power</em>}</li>
 * </ul>
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getRealGod()
 * @model abstract="true"
 * @generated
 */
public interface RealGod extends OlympusGod {
	/**
	 * Returns the value of the '<em><b>Can Create</b></em>' containment reference list.
	 * The list contents are of type {@link org.dat355.rafa.mithology.OlympusCreature}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Can Create</em>' containment reference list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getRealGod_CanCreate()
	 * @model containment="true"
	 * @generated
	 */
	EList<OlympusCreature> getCanCreate();

	/**
	 * Returns the value of the '<em><b>Children</b></em>' reference list.
	 * The list contents are of type {@link org.dat355.rafa.mithology.SemiGod}.
	 * It is bidirectional and its opposite is '{@link org.dat355.rafa.mithology.SemiGod#getParents <em>Parents</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Children</em>' reference list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getRealGod_Children()
	 * @see org.dat355.rafa.mithology.SemiGod#getParents
	 * @model opposite="parents"
	 * @generated
	 */
	EList<SemiGod> getChildren();

	/**
	 * Returns the value of the '<em><b>HP</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>HP</em>' attribute list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getRealGod_HP()
	 * @model upper="1000"
	 * @generated
	 */
	EList<Integer> getHP();

	/**
	 * Returns the value of the '<em><b>Power</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Power</em>' attribute list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getRealGod_Power()
	 * @model lower="50" upper="100"
	 * @generated
	 */
	EList<Integer> getPower();

} // RealGod
