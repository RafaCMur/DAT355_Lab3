/**
 */
package org.dat355.rafa.mithology;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Top God</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.dat355.rafa.mithology.TopGod#getSubordinates <em>Subordinates</em>}</li>
 *   <li>{@link org.dat355.rafa.mithology.TopGod#getOwns <em>Owns</em>}</li>
 * </ul>
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getTopGod()
 * @model
 * @generated
 */
public interface TopGod extends RealGod {
	/**
	 * Returns the value of the '<em><b>Subordinates</b></em>' containment reference list.
	 * The list contents are of type {@link org.dat355.rafa.mithology.NormalGod}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subordinates</em>' containment reference list.
	 * @see org.dat355.rafa.mithology.MithologyPackage#getTopGod_Subordinates()
	 * @model containment="true"
	 * @generated
	 */
	EList<NormalGod> getSubordinates();

	/**
	 * Returns the value of the '<em><b>Owns</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owns</em>' reference.
	 * @see #setOwns(SpecialWeapon)
	 * @see org.dat355.rafa.mithology.MithologyPackage#getTopGod_Owns()
	 * @model required="true"
	 * @generated
	 */
	SpecialWeapon getOwns();

	/**
	 * Sets the value of the '{@link org.dat355.rafa.mithology.TopGod#getOwns <em>Owns</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owns</em>' reference.
	 * @see #getOwns()
	 * @generated
	 */
	void setOwns(SpecialWeapon value);

} // TopGod
