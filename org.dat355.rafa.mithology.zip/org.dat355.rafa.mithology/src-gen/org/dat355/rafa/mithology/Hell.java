/**
 */
package org.dat355.rafa.mithology;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hell</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.dat355.rafa.mithology.MithologyPackage#getHell()
 * @model
 * @generated
 */
public interface Hell extends OlympusCreature {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	int attack();

} // Hell
