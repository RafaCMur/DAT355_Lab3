/**
 */
package fr.obeo.dsl.tuto.mindstorms;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Release</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.obeo.dsl.tuto.mindstorms.MindstormsPackage#getRelease()
 * @model
 * @generated
 */
public interface Release extends Action {
} // Release
