/**
 */
package fr.obeo.dsl.tuto.mindstorms;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Grab</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.obeo.dsl.tuto.mindstorms.MindstormsPackage#getGrab()
 * @model
 * @generated
 */
public interface Grab extends Action {
} // Grab
